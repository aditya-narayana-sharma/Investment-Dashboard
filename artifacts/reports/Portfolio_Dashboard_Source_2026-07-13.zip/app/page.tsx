"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Activity, CalendarDays, ChevronRight, CircleDollarSign, ExternalLink, FileText, Gauge, Mail, Mic2, Newspaper, RefreshCw, ShieldAlert, Target } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { analystCalls, axisResearchDigest, newsletterDigest, podcastNotes, scenarios } from "./portfolio-data";
import { emptySnapshot, type AllocationSlice, type KiteSnapshot, type LiveHolding } from "./live-types";

const inr = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 });
type ScenarioKey = keyof typeof scenarios;
const gainShades = ["#0f704f", "#178c61", "#23a472", "#39b785", "#63c99e"];
const RADIAN = Math.PI / 180;

type DonutLabelProps = {
  cx?: number | string;
  cy?: number | string;
  midAngle?: number;
  innerRadius?: number | string;
  outerRadius?: number | string;
  percent?: number;
  name?: string;
  payload?: AllocationSlice | LiveHolding;
};

function number(value: number | string | undefined) {
  const parsed = Number(value ?? 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function labelPoint({ cx, cy, midAngle, innerRadius, outerRadius }: DonutLabelProps, radialPosition = 0.5) {
  const inner = number(innerRadius);
  const radius = inner + (number(outerRadius) - inner) * radialPosition;
  return {
    x: number(cx) + radius * Math.cos(-number(midAngle) * RADIAN),
    y: number(cy) + radius * Math.sin(-number(midAngle) * RADIAN),
  };
}

function AllocationLabel(props: DonutLabelProps & { ring: "inner" | "middle" }) {
  const { x, y } = labelPoint(props, props.ring === "inner" ? 0.76 : 0.5);
  const percent = number(props.percent) * 100;
  const name = String(props.name ?? "");
  const compactName = props.ring === "inner"
    ? name.replace(" cap", "")
    : name.replace("Consumer internet", "Consumer").replace("Specialty chemicals", "Chemicals");

  return (
    <text x={x} y={y} textAnchor="middle" dominantBaseline="central" className={`donut-data-label ${props.ring}${percent < 6 ? " compact" : ""}`}>
      <tspan x={x} dy="-0.45em">{compactName}</tspan>
      <tspan x={x} dy="1.15em">{percent.toFixed(1)}%</tspan>
    </text>
  );
}

function HoldingLabel(props: DonutLabelProps) {
  const { x, y } = labelPoint(props);
  const holding = props.payload as LiveHolding | undefined;
  if (!holding) return null;
  const symbol = holding.symbol.replace("ICICIBANK", "ICICI").replace("BHARTIARTL", "AIRTEL").replace("JSWENERGY", "JSW");
  const signed = (value: number) => `${value >= 0 ? "+" : ""}${value.toFixed(1)}%`;

  return (
    <text x={x} y={y} textAnchor="middle" dominantBaseline="central" className="donut-data-label outer">
      <tspan x={x} dy="-1.35em" className="symbol">{symbol}</tspan>
      <tspan x={x} dy="1.05em">{holding.weight.toFixed(1)}%</tspan>
      <tspan x={x} dy="1.05em">U {signed(holding.pnlPct)}</tspan>
      <tspan x={x} dy="1.05em">D {signed(holding.dayPct)}</tspan>
    </text>
  );
}

function RiskPill({ value }: { value: string }) {
  const tone = value.toLowerCase().includes("high") ? "red" : value.toLowerCase().includes("low") ? "green" : "amber";
  return <span className={`pill ${tone}`}>{value}</span>;
}

function SectionHeading({ number, title, note }: { number: string; title: string; note: string }) {
  return <div className="section-heading"><span>{number}</span><div><h2>{title}</h2><p>{note}</p></div></div>;
}

export default function Home() {
  const [scenarioKey, setScenarioKey] = useState<ScenarioKey>("base");
  const [view, setView] = useState<"holdings" | "activity">("holdings");
  const [snapshot, setSnapshot] = useState<KiteSnapshot>(emptySnapshot);
  const [refreshing, setRefreshing] = useState(true);
  const scenario = scenarios[scenarioKey];
  const { holdings, portfolio, orders, gtts, marketCapAllocation, sectorAllocation, asOf } = snapshot;
  const isLive = snapshot.status === "live";
  const currentBySymbol = useMemo(() => new Map(holdings.map((holding) => [holding.symbol, holding.price])), [holdings]);

  const refreshKite = useCallback(async () => {
    setRefreshing(true);
    try {
      const response = await fetch("/api/kite/snapshot", { cache: "no-store" });
      const data = await response.json() as KiteSnapshot;
      setSnapshot(data);
    } catch (error) {
      setSnapshot({ ...emptySnapshot, message: error instanceof Error ? error.message : "Could not load live Kite data." });
    } finally {
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    const initial = window.setTimeout(() => void refreshKite(), 0);
    const interval = window.setInterval(() => void refreshKite(), 5 * 60 * 1000);
    return () => { window.clearTimeout(initial); window.clearInterval(interval); };
  }, [refreshKite]);

  const liveMoney = (value: number) => isLive ? inr.format(value) : "—";

  return (
    <main className="dashboard-app">
      <header className="masthead">
        <div>
          <div className="eyebrow">PORTFOLIO INTELLIGENCE</div>
          <h1>Investment Brief</h1>
          <p>Quarter outlook, oil/geopolitical exposure, flows and analyst positioning</p>
        </div>
        <div className="status-panel">
          <div><Activity size={16}/><span>Kite snapshot</span><b className={snapshot.status}>{isLive ? "Live" : snapshot.status === "auth_required" ? "Authenticate" : "Unavailable"}</b></div>
          <small>As of {asOf}</small>
          <a href="/report"><FileText size={15}/> Open print report</a>
        </div>
      </header>

      <section className={`live-feed-banner ${snapshot.status}`}>
        <div><Activity size={17}/><span><b>{isLive ? "Live Kite Connect data" : snapshot.status === "auth_required" ? "Kite authentication required" : "Waiting for live Kite data"}</b><small>{snapshot.message}</small></span></div>
        <div className="live-feed-actions">
          {snapshot.authUrl && <a href={snapshot.authUrl} target="_blank" rel="noreferrer">Authenticate Kite <ExternalLink size={14}/></a>}
          <button onClick={()=>void refreshKite()} disabled={refreshing} title="Refresh Kite data now"><RefreshCw size={15} className={refreshing?"spin":""}/><span>{refreshing?"Refreshing":"Refresh now"}</span></button>
          <em>Auto-refresh · 5 min</em>
        </div>
      </section>

      <section className="metrics-strip">
        <article><span>Portfolio value</span><b>{liveMoney(portfolio.value)}</b><small>{isLive ? `${holdings.length} open equity exposures` : "Live Kite data required"}</small></article>
        <article><span>Unrealised P&amp;L</span><b className={portfolio.pnl>=0?"positive":"negative"}>{isLive ? `${portfolio.pnl>=0?"+":""}${inr.format(portfolio.pnl)}` : "—"}</b><small>{isLive ? `${portfolio.pnlPct>=0?"+":""}${portfolio.pnlPct.toFixed(2)}% on invested cost` : "No static fallback"}</small></article>
        <article><span>Top-two concentration</span><b className="warning">{isLive ? `${portfolio.topTwo.toFixed(1)}%` : "—"}</b><small>{isLive ? holdings.slice(0,2).map(h=>h.name).join(" + ") : "Calculated from live positions"}</small></article>
        <article><span>Available equity margin</span><b>{liveMoney(portfolio.equityMargin)}</b><small>Live equity segment net margin</small></article>
      </section>

      <section className="executive-band">
        <div className="signal"><ShieldAlert size={22}/><div><b>Portfolio stance: moderately constructive, concentration-limited</b><p>Airtel and ICICI Bank provide relative resilience; Eternal and Aether carry the highest valuation and oil-linked risk.</p></div></div>
        <div className="market-ticker"><span>BRENT</span><b>$78.8-79.6</b><small>13 Jul range from AP updates</small></div>
        <div className="market-ticker"><span>10 JUL FLOWS</span><b>FII +₹2,604cr</b><small>DII +₹2,020cr, provisional</small></div>
      </section>

      <SectionHeading number="1" title="Portfolio snapshot" note="Kite holdings plus deduplicated CNC positions" />
      <div className="dashboard-grid">
        <section className="panel chart-panel nested-chart-panel">
          <div className="panel-title"><div><h3>Nested portfolio allocation</h3><p>Outer: holdings and P&amp;L · middle: sector · inner: AMFI market-cap tier</p></div><Gauge size={18}/></div>
          {isLive ? <><div className="nested-chart-wrap">
            <ResponsiveContainer width="100%" height={410}>
              <PieChart margin={{top:12,right:12,bottom:12,left:12}}>
                <Pie data={marketCapAllocation} dataKey="value" nameKey="name" innerRadius="23%" outerRadius="42%" paddingAngle={1} isAnimationActive={false} labelLine={false} label={(props) => <AllocationLabel {...props} ring="inner"/>}>{marketCapAllocation.map(item => <Cell key={item.name} fill={item.color}/>)}</Pie>
                <Pie data={sectorAllocation} dataKey="value" nameKey="name" innerRadius="46%" outerRadius="66%" paddingAngle={1} isAnimationActive={false} labelLine={false} label={(props) => <AllocationLabel {...props} ring="middle"/>}>{sectorAllocation.map(item => <Cell key={item.name} fill={item.color}/>)}</Pie>
                <Pie data={holdings} dataKey="value" nameKey="symbol" innerRadius="70%" outerRadius="96%" paddingAngle={1.5} isAnimationActive={false} labelLine={false} label={(props) => <HoldingLabel {...props}/> }>
                  {holdings.map((h,index) => <Cell key={h.symbol} fill={h.pnl >= 0 ? gainShades[index] : "#c33f47"} fillOpacity={h.dayPnl >= 0 ? 1 : .52} stroke={h.dayPnl >= 0 ? "#ffffff" : "#9b2f36"} strokeWidth={h.dayPnl >= 0 ? 2 : 1.5}/>) }
                </Pie>
                <Tooltip formatter={(value,name) => [inr.format(Number(value)),String(name)]}/>
              </PieChart>
            </ResponsiveContainer>
            <div className="nested-center"><b className={portfolio.pnl>=0?"positive":"negative"}>{portfolio.pnl>=0?"+":""}{inr.format(portfolio.pnl)}</b><span>Unrealised · {portfolio.pnlPct>=0?"+":""}{portfolio.pnlPct.toFixed(2)}%</span><strong className={portfolio.dayPnl>=0?"positive":"negative"}>{portfolio.dayPnl>=0?"+":""}{inr.format(portfolio.dayPnl)}</strong><span>Day · {portfolio.dayPct>=0?"+":""}{portfolio.dayPct.toFixed(2)}%</span></div>
          </div>
          <div className="ring-key"><span><i className="ring outer"/>Outer · holding weight + U/Day P&amp;L</span><span><i className="ring middle"/>Middle · industry/sector</span><span><i className="ring inner"/>Inner · market-cap tier</span><span><i className="shade"/>Shaded outer segment = negative day P&amp;L</span></div></> : <div className="live-empty"><Activity size={24}/><b>Live allocation is unavailable</b><p>{snapshot.message}</p>{snapshot.authUrl && <a href={snapshot.authUrl} target="_blank" rel="noreferrer">Authenticate Kite <ExternalLink size={14}/></a>}</div>}
        </section>
        <section className="panel chart-panel">
          <div className="panel-title"><div><h3>Exposure scores</h3><p>Analyst-assigned qualitative scale, 1 low to 5 high</p></div><ShieldAlert size={18}/></div>
          {isLive ? <ResponsiveContainer width="100%" height={292}>
            <BarChart data={holdings} layout="vertical" margin={{left:4,right:12}}><CartesianGrid strokeDasharray="3 3" horizontal={false}/><XAxis type="number" domain={[0,5]} tickCount={6}/><YAxis dataKey="symbol" type="category" width={92} tick={{fontSize:11}}/><Tooltip/><Legend/><Bar dataKey="oil" name="Oil / war" fill="#df6651" radius={[0,3,3,0]} isAnimationActive={false}/><Bar dataKey="flow" name="FII / flow" fill="#2563a6" radius={[0,3,3,0]} isAnimationActive={false}/></BarChart>
          </ResponsiveContainer> : <div className="live-empty compact"><ShieldAlert size={24}/><b>Exposure chart waits for live positions</b><p>No stored price snapshot is displayed.</p></div>}
        </section>
      </div>

      <section className="panel holdings-panel">
        <div className="panel-title"><div><h3>Positions</h3><p>Live-session prices from Kite; no intraday quote history was available</p></div><div className="segmented"><button onClick={()=>setView("holdings")} className={view==="holdings"?"active":""}>Holdings</button><button onClick={()=>setView("activity")} className={view==="activity"?"active":""}>Orders &amp; GTTs</button></div></div>
        {view === "holdings" ? <div className="table-scroll"><table><thead><tr><th>Position</th><th>Qty</th><th>Avg</th><th>Last</th><th>Value</th><th>Unrealised P&amp;L</th><th>Day P&amp;L</th><th>Weight</th><th>Quarter stance</th><th>Risk</th></tr></thead><tbody>{holdings.map(h=><tr key={h.symbol}><td><b>{h.name}</b><small>{h.symbol} · {h.sector} · {h.marketCap}</small></td><td>{h.qty}</td><td>{inr.format(h.avg)}</td><td>{inr.format(h.price)}</td><td>{inr.format(h.value)}</td><td className={h.pnl>=0?"positive":"negative"}>{h.pnl>=0?"+":""}{inr.format(h.pnl)}<small>{h.pnlPct>=0?"+":""}{h.pnlPct.toFixed(2)}%</small></td><td className={h.dayPnl>=0?"positive":"negative"}>{h.dayPnl>=0?"+":""}{inr.format(h.dayPnl)}<small>{h.dayPct>=0?"+":""}{h.dayPct.toFixed(2)}%</small></td><td><div className="weight-cell"><span style={{width:`${Math.min(100,h.weight*2.1)}%`,background:h.color}}/>{h.weight.toFixed(1)}%</div></td><td><b>{h.quarter}</b><small>{h.stance}</small></td><td><RiskPill value={h.risk}/></td></tr>)}{!holdings.length && <tr><td colSpan={10}><div className="table-empty">No static positions are shown. Connect Kite to load the live portfolio.</div></td></tr>}</tbody></table></div> : <div className="activity-grid"><div><h4>Orders</h4>{orders.map(o=><div className="activity-row" key={o.id}><div><b>{o.symbol}</b><small>{o.side} {o.qty} · {o.type}</small></div><strong>{inr.format(o.price)}</strong><span className={`pill ${o.status.toLowerCase()==="complete"?"green":"amber"}`}>{o.status}</span></div>)}{!orders.length&&<div className="table-empty">No live orders loaded.</div>}</div><div><h4>GTT register</h4>{gtts.map(g=><div className="activity-row" key={g.id}><div><b>{g.symbol}</b><small>{g.side} {g.qty} · trigger {inr.format(g.trigger)}</small></div><strong>{inr.format(g.limit)}</strong><span className={`pill ${g.status.toLowerCase()==="active"?"amber":"green"}`}>{g.status}</span></div>)}{!gtts.length&&<div className="table-empty">No live GTTs loaded.</div>}</div></div>}
      </section>

      <SectionHeading number="2" title="Macro scenario lab" note="Relative portfolio impact, not a forecast of returns" />
      <section className="scenario-shell">
        <div className="scenario-tabs">{(Object.keys(scenarios) as ScenarioKey[]).map(key=><button key={key} className={scenarioKey===key?"active":""} onClick={()=>setScenarioKey(key)}><span className={`dot ${scenarios[key].tone}`}/><b>{scenarios[key].label}</b><small>{scenarios[key].oil}</small></button>)}</div>
        <div className={`scenario-body ${scenario.tone}`}><div className="scenario-copy"><span>CURRENT VIEW</span><h3>{scenario.label}</h3><p>{scenario.summary}</p></div><div><small>Relative leaders</small><b>{scenario.leaders}</b></div><div><small>Relative laggards</small><b>{scenario.laggards}</b></div><div><small>Framework response</small><b>{scenario.action}</b></div></div>
      </section>

      <SectionHeading number="3" title="Analyst call matrix" note="Targets are reference points, not quarter forecasts" />
      <section className="panel table-scroll"><table><thead><tr><th>Stock</th><th>Source / house</th><th>Call</th><th>Target</th><th>Implied vs live</th><th>Published</th><th>What matters</th></tr></thead><tbody>{analystCalls.map(a=>{const current=currentBySymbol.get(a.symbol);const implied=current?(a.target/current-1)*100:null;return <tr key={a.symbol}><td><b>{a.symbol}</b></td><td>{a.house}</td><td><span className="pill blue">{a.rating}</span></td><td>{inr.format(a.target)}</td><td className={implied===null?"":implied>=0?"positive":"negative"}>{implied===null?"—":`${implied>=0?"+":""}${implied.toFixed(1)}%`}</td><td>{a.date}</td><td>{a.thesis}</td></tr>})}</tbody></table><div className="table-note"><Target size={16}/><span>Implied upside is recalculated from each live Kite last price. NSE is used for filings, results and flow data; it does not issue buy/sell recommendations.</span></div></section>

      <SectionHeading number="4" title="Live intelligence digest" note="Today in Apple Mail and Podcasts · source descriptions are summarised, not treated as investment recommendations" />
      <section className="digest-grid">
        <article className="panel digest-panel"><div className="panel-title"><div><h3>Newsletter digest</h3><p>iCloud · Newsletters mailbox</p></div><Mail size={18}/></div><div className="digest-list">{newsletterDigest.map(item=><div key={`${item.source}-${item.title}`}><span>{item.time}</span><div><b>{item.source}</b><h4>{item.title}</h4><p>{item.summary}</p></div></div>)}</div></article>
        <article className="panel digest-panel"><div className="panel-title"><div><h3>Axis Research</h3><p>iCloud · Axis Research mailbox</p></div><Newspaper size={18}/></div><div className="digest-list">{axisResearchDigest.map(item=><div key={item.title}><span>{item.time}</span><div><h4>{item.title}</h4><p>{item.summary}</p></div></div>)}</div></article>
        <article className="panel digest-panel"><div className="panel-title"><div><h3>Podcast summaries</h3><p>Apple Podcasts · seven episodes today</p></div><Mic2 size={18}/></div><div className="digest-list podcast-digest">{podcastNotes.map(([name,note],index)=><div key={name}><span>{String(index+1).padStart(2,"0")}</span><div><h4>{name}</h4><p>{note}</p></div></div>)}</div><div className="digest-note">Description-backed summaries: Apple&apos;s transcript pane remained attached to a previously loaded episode.</div></article>
      </section>

      <section className="bottom-grid">
        <article className="panel catalyst-card"><div className="panel-title"><div><h3>Earnings calendar</h3><p>Apple Calendar cross-check</p></div><CalendarDays size={18}/></div><div className="calendar-date"><span>18</span><div><b>ICICI Bank Q1 FY27</b><small>Saturday, 18 Jul 2026</small></div><ChevronRight size={18}/></div><p>No portfolio holding was listed as reporting today or during 6-12 Jul. LTF was the only earnings event in that local calendar last week.</p></article>
        <article className="panel"><div className="panel-title"><div><h3>Decision framework</h3><p>Research actions, not trade instructions</p></div><CircleDollarSign size={18}/></div><ul className="action-list"><li><span className="dot red"/><b>Concentration:</b> use new capital to dilute the 72.9% top-two weight.</li><li><span className="dot amber"/><b>Oil trigger:</b> above $90 for two weeks, re-underwrite Aether and Eternal risk.</li><li><span className="dot green"/><b>Defensive anchor:</b> Airtel has the lowest direct oil sensitivity.</li></ul></article>
      </section>

      <footer><p>Educational portfolio research. Not personalised investment advice and no orders were placed.</p><p>{isLive ? `Live Kite values: ${asOf}` : "Kite values unavailable · no static fallback"} · Five-minute auto-refresh.</p></footer>
    </main>
  );
}
