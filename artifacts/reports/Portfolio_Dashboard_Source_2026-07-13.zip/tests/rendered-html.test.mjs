import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function render(path = "/") {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}-${path}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request(`http://localhost${path}`, { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("server-renders the portfolio dashboard", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<title>Portfolio Investment Brief<\/title>/i);
  assert.match(html, /Investment Brief/);
  assert.match(html, /Top-two concentration/);
  assert.match(html, /Live Kite data required/);
  assert.match(html, /Auto-refresh · 5 min/);
  assert.match(html, /Macro scenario lab/);
  assert.match(html, /Analyst call matrix/);
  assert.match(html, /Nested portfolio allocation/);
  assert.match(html, /Newsletter digest/);
  assert.match(html, /Axis Research/);
  assert.match(html, /Podcast summaries/);
  assert.match(html, /ICICI Bank Q1 FY27/);
});

test("server-renders the print report and keeps controls interactive", async () => {
  const [response, page, liveServer, liveRoute, packageJson] = await Promise.all([
    render("/report"),
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/kite-live-server.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/api/kite/snapshot/route.ts", import.meta.url), "utf8"),
    readFile(new URL("../package.json", import.meta.url), "utf8"),
  ]);
  assert.equal(response.status, 200);

  const html = await response.text();
  assert.match(html, /Portfolio Analysis/);
  assert.match(html, /Macro shock map/);
  assert.match(html, /Source register/);
  assert.match(html, /Transcript limitation/);

  assert.match(page, /setScenarioKey/);
  assert.match(page, /setView/);
  assert.match(page, /Orders &amp; GTTs/);
  assert.match(page, /5 \* 60 \* 1000/);
  assert.match(page, /\/api\/kite\/snapshot/);
  assert.match(page, /No static positions are shown/);
  assert.match(page, /Shaded outer segment = negative day P&amp;L/);
  assert.match(page, /isAnimationActive=\{false\}/);
  assert.match(liveServer, /callTool\("get_holdings"\)/);
  assert.match(liveServer, /callTool\("get_positions"\)/);
  assert.match(liveServer, /callTool\("get_orders"\)/);
  assert.match(liveServer, /callTool\("get_gtts"\)/);
  assert.match(liveServer, /AUTH_URL_MAX_AGE_MS = 20 \* 60 \* 1000/);
  assert.match(liveServer, /authUrlCreatedAt = Date\.now\(\)/);
  assert.doesNotMatch(liveServer, /name\.startsWith\("get_"\)/);
  assert.match(liveServer, /if \(!rawBody\.trim\(\)\) return/);
  assert.match(liveRoute, /HttpOnly; SameSite=Strict/);
  assert.match(liveRoute, /Cache-Control.*no-store/);
  assert.match(packageJson, /ensure-kite-server\.sh/);
});
