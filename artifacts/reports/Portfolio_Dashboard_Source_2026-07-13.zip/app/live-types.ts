export type LiveHolding = {
  symbol: string;
  name: string;
  sector: string;
  marketCap: string;
  qty: number;
  avg: number;
  price: number;
  value: number;
  pnl: number;
  pnlPct: number;
  dayPnl: number;
  dayPct: number;
  weight: number;
  risk: string;
  stance: string;
  oil: number;
  flow: number;
  quarter: string;
  color: string;
};

export type AllocationSlice = {
  name: string;
  value: number;
  weight: number;
  color: string;
};

export type LiveOrder = {
  id: string;
  symbol: string;
  side: string;
  qty: number;
  type: string;
  price: number;
  status: string;
};

export type LiveGtt = {
  id: string;
  symbol: string;
  side: string;
  qty: number;
  trigger: number;
  limit: number;
  status: string;
  expiry: string;
};

export type KiteSnapshot = {
  status: "live" | "auth_required" | "unavailable";
  asOf: string;
  message: string;
  authUrl?: string;
  portfolio: {
    invested: number;
    value: number;
    pnl: number;
    pnlPct: number;
    dayPnl: number;
    dayPct: number;
    topTwo: number;
    equityMargin: number;
  };
  holdings: LiveHolding[];
  orders: LiveOrder[];
  gtts: LiveGtt[];
  marketCapAllocation: AllocationSlice[];
  sectorAllocation: AllocationSlice[];
};

export const emptySnapshot: KiteSnapshot = {
  status: "unavailable",
  asOf: "Waiting for Kite Connect",
  message: "Live Kite data has not loaded yet.",
  portfolio: { invested: 0, value: 0, pnl: 0, pnlPct: 0, dayPnl: 0, dayPct: 0, topTwo: 0, equityMargin: 0 },
  holdings: [],
  orders: [],
  gtts: [],
  marketCapAllocation: [],
  sectorAllocation: [],
};
